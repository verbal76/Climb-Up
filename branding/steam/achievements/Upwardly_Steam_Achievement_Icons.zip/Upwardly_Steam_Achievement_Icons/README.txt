Upwardly - Steam achievement icons (Steam App ID 5427130)

54 PNG files, 256 x 256: for each achievement, <API name>_unlocked.png goes in "Achieved Icon" and
<API name>_locked.png goes in "Unachieved Icon" on the Steamworks Achievements page.
manifest.csv lists every API name with its display name, description and both files.
Step-by-step entry: docs/STEAM_ACHIEVEMENTS_ENTRY_SHEET.md in the game repository.
Artwork: original Hot Attic Games work, from renders of the game's own CC0 models (Quaternius, Kenney).
