# Assets and provenance

Every external asset used by the game must have a row here with its exact source URL, creator, license and download date.
Planned resolutions from Game Designer are listed first; the build appends one row per actual file.

## Asset strategy

Asset sources in priority order: 1) appropriately licensed free assets (CC0/public domain; verify every license); 2) for whatever remains uncovered, original/procedural work created by the builder.

| Need | Resolution | License | Source / instructions |
|---|---|---|---|
| characters | external cc0 | CC0 1.0 / public domain | Kenney (https://kenney.nl/assets); Quaternius (https://quaternius.com); Poly Haven (https://polyhaven.com); OpenGameArt.org (CC0-filtered) (https://opengameart.org); itch.io (CC0-tagged assets) (https://itch.io/game-assets/assets-cc0) Choose ONE visually coherent set (consistency over variety). If no coherent clean-license set covers this need, build the original procedural fallback: Generate meshes from primitives and parametric/lathe/extrude builders with vertex colors or simple materials; deterministic seeds. |
| environment | external cc0 | CC0 1.0 / public domain | Kenney (https://kenney.nl/assets); Quaternius (https://quaternius.com); Poly Haven (https://polyhaven.com); OpenGameArt.org (CC0-filtered) (https://opengameart.org); itch.io (CC0-tagged assets) (https://itch.io/game-assets/assets-cc0) Choose ONE visually coherent set (consistency over variety). If no coherent clean-license set covers this need, build the original procedural fallback: Generate meshes from primitives and parametric/lathe/extrude builders with vertex colors or simple materials; deterministic seeds. |
| materials | external cc0 | CC0 1.0 / public domain | Poly Haven (https://polyhaven.com); ambientCG (https://ambientcg.com) Choose ONE visually coherent set (consistency over variety). If no coherent clean-license set covers this need, build the original procedural fallback: Generate tileable textures with noise/pattern shaders baked at build time. |
| ui_kit | external cc0 | CC0 1.0 / public domain | Kenney (https://kenney.nl/assets); OpenGameArt.org (CC0-filtered) (https://opengameart.org); itch.io (CC0-tagged assets) (https://itch.io/game-assets/assets-cc0) Choose ONE visually coherent set (consistency over variety). If no coherent clean-license set covers this need, build the original procedural fallback: Build the UI from engine-native drawing primitives (rounded rects, gradients, icons drawn as vectors) with a shared theme. |
| vfx | external cc0 | CC0 1.0 / public domain | Kenney (https://kenney.nl/assets) Choose ONE visually coherent set (consistency over variety). If no coherent clean-license set covers this need, build the original procedural fallback: Use engine particle systems and shaders with a shared small palette. |
| font | external cc0 | CC0 1.0 / public domain | Kenney (https://kenney.nl/assets) Choose ONE visually coherent set (consistency over variety). If no coherent clean-license set covers this need, build the original procedural fallback: Use a CC0 font from a blanket-CC0 source, or generate a bitmap font from code. |
| sfx | external cc0 | CC0 1.0 / public domain | Kenney (https://kenney.nl/assets); OpenGameArt.org (CC0-filtered) (https://opengameart.org); itch.io (CC0-tagged assets) (https://itch.io/game-assets/assets-cc0); Freesound (CC0-filtered) (https://freesound.org) Choose ONE visually coherent set (consistency over variety). If no coherent clean-license set covers this need, build the original procedural fallback: Synthesize effects with a small sfxr-style synthesizer (waveform, envelope, filter) rendered at build time with seeded parameters per effect. |
| music | external cc0 | CC0 1.0 / public domain | Kenney (https://kenney.nl/assets); OpenGameArt.org (CC0-filtered) (https://opengameart.org); itch.io (CC0-tagged assets) (https://itch.io/game-assets/assets-cc0); Freesound (CC0-filtered) (https://freesound.org) Choose ONE visually coherent set (consistency over variety). If no coherent clean-license set covers this need, build the original procedural fallback: Synthesize loopable music from a small procedural sequencer (scales, chord progressions, simple instruments) rendered at build time. |


## Owner-supplied branding (use as-is; never replace or regenerate)

| Slot | File in this package | Original name | Size | SHA-256 | License |
|---|---|---|---|---|---|
| studio_splash | `branding/master/studio_splash_e3d9bb56.png` | Hot_Attic_Games_Master_Logo_ALPHA_FINAL.png | 1536x1024 | e3d9bb5653eafb783eede827606e7ac73a4e45564a1c25b1ed13ad1429f48c4e | owner-supplied |

## Actual files

| File | Source URL | Creator | License | Downloaded |
|---|---|---|---|---|
